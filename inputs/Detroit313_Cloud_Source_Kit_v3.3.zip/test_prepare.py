import tempfile
import unittest
import zipfile
from pathlib import Path
from prepare_detroit_sources import prepare, FILES

class TestPrepare(unittest.TestCase):
    def test_complete(self):
        with tempfile.TemporaryDirectory() as d:
            src=Path(d)/'ok.zip'
            with zipfile.ZipFile(src,'w') as z:
                for f in FILES:z.writestr('version32/'+f,b'valid')
            self.assertEqual(len(prepare(src,Path(d)/'out')),len(FILES))
    def test_missing(self):
        with tempfile.TemporaryDirectory() as d:
            src=Path(d)/'missing.zip'
            with zipfile.ZipFile(src,'w') as z:z.writestr('README.md','x')
            with self.assertRaises(ValueError):prepare(src,Path(d)/'out')
    def test_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            src=Path(d)/'unsafe.zip'
            with zipfile.ZipFile(src,'w') as z:z.writestr('../invalid','x')
            with self.assertRaises(ValueError):prepare(src,Path(d)/'out')

if __name__=='__main__':unittest.main()
