"""Safely extract the known Detroit313 authoring files from a v3.2 source archive.

No proprietary Studio or game binaries are extracted or copied.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import zipfile

FILES = [
    'build_detroit_studio_scene.py', 'BUILD_DETROIT_WINDOWS.ps1',
    'preflight.py', 'SPAWN_SURVEY_v24.json', 'apply_textures_in_blender.py',
    'exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_TerrainCollision_CANDIDATE.glb',
    'exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_Roads_VISUAL_ONLY.glb',
    'exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_Buildings_VISUAL_ONLY.glb',
]

def prepare(archive, output):
    archive, output = Path(archive), Path(output)
    with zipfile.ZipFile(archive) as z:
        matched = {}
        for info in z.infolist():
            normalized = info.filename.replace('\\', '/')
            parts = PurePosixPath(normalized).parts
            if normalized.startswith('/') or '..' in parts:
                raise ValueError('Unsafe archive path: ' + info.filename)
            if info.is_dir(): continue
            for required in FILES:
                if normalized == required or normalized.endswith('/' + required):
                    if required in matched: raise ValueError('Duplicate asset: ' + required)
                    matched[required] = info
        absent = sorted(set(FILES) - set(matched))
        if absent: raise ValueError('Required Detroit assets missing: ' + ', '.join(absent))
        manifest=[]
        for required in FILES:
            info = matched[required]
            raw = z.read(info)
            target = output / required
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            manifest.append({'path': required, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    (output / 'DETROIT_INPUT_MANIFEST.json').write_text(json.dumps({'source':archive.name,'files': manifest},indent=2)+'\n')
    return manifest

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('archive', type=Path)
    p.add_argument('--output', type=Path, default=Path('inputs/Detroit313_Source'))
    args=p.parse_args()
    result=prepare(args.archive,args.output)
    print('Prepared',len(result),'Detroit source assets in',args.output)
