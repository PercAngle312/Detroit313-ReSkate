"""Blender 4.x: open existing Detroit313 .blend, then run this script. Saves a separately named textured .blend."""
import bpy, json, pathlib, sys
project=pathlib.Path(__file__).resolve().parent
cfg=json.loads((project/'MATERIAL_LIBRARY.json').read_text())

def build_material(name, info):
 m=bpy.data.materials.get('D313_'+name) or bpy.data.materials.new('D313_'+name)
 m.use_nodes=True
 nodes=m.node_tree.nodes; links=m.node_tree.links; nodes.clear()
 out=nodes.new('ShaderNodeOutputMaterial'); out.location=(620,0)
 bsdf=nodes.new('ShaderNodeBsdfPrincipled');bsdf.location=(300,0)
 links.new(bsdf.outputs['BSDF'],out.inputs['Surface'])
 uv=nodes.new('ShaderNodeTexCoord');uv.location=(-900,0)
 mapping=nodes.new('ShaderNodeVectorMath'); mapping.operation='SCALE';mapping.location=(-650,0)
 mapping.inputs[3].default_value=1.0/float(info['tile_m'])
 links.new(uv.outputs['UV'],mapping.inputs[0])
 image_nodes={}
 for channel,y in [('basecolor',250),('normal',-50),('roughness',-350)]:
  node=nodes.new('ShaderNodeTexImage');node.location=(-390,y)
  fn=project/info['images'][channel]
  if not fn.is_file():raise RuntimeError('Missing texture: '+str(fn))
  node.image=bpy.data.images.load(str(fn),check_existing=True)
  node.image.pack()
  if channel!='basecolor':node.image.colorspace_settings.name='Non-Color'
  links.new(mapping.outputs['Vector'],node.inputs['Vector'])
  image_nodes[channel]=node
 links.new(image_nodes['basecolor'].outputs['Color'],bsdf.inputs['Base Color'])
 links.new(image_nodes['roughness'].outputs['Color'],bsdf.inputs['Roughness'])
 normal=nodes.new('ShaderNodeNormalMap');normal.location=(40,-140)
 links.new(image_nodes['normal'].outputs['Color'],normal.inputs['Color'])
 links.new(normal.outputs['Normal'],bsdf.inputs['Normal'])
 m['detroit_source']='original procedural visualization'
 return m

def projected_uv(obj):
 # Unique per mesh, UV from local mesh positions (2m texture repeat controlled via node scale).
 mesh=obj.data
 if mesh.users>1: obj.data=mesh.copy();mesh=obj.data
 layer=mesh.uv_layers.get('D313_meter_projection') or mesh.uv_layers.new(name='D313_meter_projection')
 for poly in mesh.polygons:
  n=poly.normal
  for li in poly.loop_indices:
   co=mesh.vertices[mesh.loops[li].vertex_index].co
   if abs(n.z)>=max(abs(n.x),abs(n.y)): uv=(co.x,co.y)
   elif abs(n.x)>=abs(n.y):uv=(co.y,co.z)
   else:uv=(co.x,co.z)
   layer.data[li].uv=uv
 mesh.uv_layers.active=layer

def group_for_object(o):
 label=o.name.lower()
 if 'terrain' in label:return None  # Keep Studio terrain collision/gameplay material unchanged
 if 'road' in label:return 'asphalt_aged'
 if 'building' in label:return 'brick_red'
 return None

# Fail closed if the intended Detroit source scene was not loaded.
mesh_objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
road_objects=[o for o in mesh_objects if group_for_object(o)=='asphalt_aged']
building_objects=[o for o in mesh_objects if group_for_object(o)=='brick_red']
terrain_objects=[o for o in mesh_objects if 'terrain' in o.name.lower()]
if not terrain_objects or not road_objects or not building_objects:
 raise RuntimeError('Incomplete Detroit scene: terrain, road, and building mesh groups must all exist before texturing')

def gameplay_snapshot(obj):
 sk=getattr(obj,'sk8_object',None)
 return {'collision_mode':str(getattr(sk,'collision_mode','unavailable')),
         'mesh':obj.data.name,
         'materials':[m.name if m else None for m in obj.data.materials],
         'vertices':len(obj.data.vertices),'faces':len(obj.data.polygons)}
terrain_before={o.name:gameplay_snapshot(o) for o in terrain_objects}
visual_before={o.name:gameplay_snapshot(o)['collision_mode'] for o in road_objects+building_objects}
made={name:build_material(name,info) for name,info in cfg['materials'].items()}
assigned=[]
for obj in bpy.context.scene.objects:
 if obj.type!='MESH':continue
 group=group_for_object(obj)
 if group is None:continue
 projected_uv(obj)
 original_surface=[]
 for existing in obj.data.materials:
  original_surface.append(getattr(getattr(existing,'sk8_material',None),'surface',None))
 # Copy the mesh before modifying material slots, keeping imported source data independent.
 obj.data=obj.data.copy()
 obj.data.materials.clear()
 mat=made[group]
 obj.data.materials.append(mat)
 # ReSkate material data is not silently guessed. Preserve surface label where supported.
 sk=getattr(mat,'sk8_material',None)
 if sk is not None:
  try: sk.surface=cfg['materials'][group]['surface_class']
  except Exception as ex: print('Studio surface could not be set:',ex)
 assigned.append({'object':obj.name,'material':mat.name,'prior_surface_values':original_surface,'collision_mode':getattr(getattr(obj,'sk8_object',None),'collision_mode','unknown')})
if len(assigned)!=len(road_objects)+len(building_objects):
 raise RuntimeError('Material routing incomplete: expected %d assignments, received %d' % (len(road_objects)+len(building_objects),len(assigned)))
terrain_after={o.name:gameplay_snapshot(o) for o in terrain_objects}
visual_after={o.name:gameplay_snapshot(o)['collision_mode'] for o in road_objects+building_objects}
if terrain_before!=terrain_after or visual_before!=visual_after:
 raise RuntimeError('Gameplay collision properties or terrain materials were altered during visual texture pass')
output=project/'build_output'/'Detroit313_CampusMartius_TEXTURED.blend' 
output.parent.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(output))
(project/'TEXTURE_ASSIGNMENT_AUDIT.json').write_text(json.dumps({'assigned':assigned,'saved':str(output),'not_compiled':True,'terrain_unmodified':True,'visual_only':True,'terrain_before':terrain_before,'terrain_after':terrain_after,'visual_collision_before':visual_before,'visual_collision_after':visual_after,'required_object_counts':{'terrain':len(terrain_objects),'roads':len(road_objects),'buildings':len(building_objects)}},indent=2))
print('D313_TEXTURED_SCENE',output,'objects',len(assigned))
