"""Run in Blender: blender -b --python build_detroit_studio_scene.py -- <studio-zip> <campus-v24-root> <output.blend>"""
import bpy, sys, pathlib, json, zipfile, tempfile, importlib.util
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
if len(args)!=3: raise SystemExit('Usage: -- ReSkate_Studio.zip v24_project_folder output.blend')
studio_zip,root,dest=map(pathlib.Path,args)
if not studio_zip.is_file() or not root.is_dir(): raise RuntimeError('Missing Studio zip or source directory')
with tempfile.TemporaryDirectory() as temp:
    with zipfile.ZipFile(studio_zip) as z:
        addon='Native/Blender/sk8_map_export.py'
        z.extract(addon,temp)
    spec=importlib.util.spec_from_file_location('sk8_map_export',str(pathlib.Path(temp)/addon))
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod);mod.register()
    bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
    bpy.context.scene.unit_settings.system='METRIC'
    bpy.context.scene.sk8_map.scale=1.0
    bpy.context.scene.sk8_map.selected_only=False
    sources=[
      ('Terrain','exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_TerrainCollision_CANDIDATE.glb','triangle_mesh'),
      ('Roads_Provisional','exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_Roads_VISUAL_ONLY.glb','none'),
      ('Buildings_Provisional','exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_Buildings_VISUAL_ONLY.glb','none'),
    ]
    audit=[]
    for label,rel,collision in sources:
        source=root/rel
        if not source.exists(): raise RuntimeError('Missing '+str(source))
        before=set(bpy.data.objects)
        bpy.ops.import_scene.gltf(filepath=str(source))
        meshes=[o for o in (set(bpy.data.objects)-before) if o.type=='MESH']
        if not meshes: raise RuntimeError('No meshes imported from '+rel)
        for obj in meshes:
            obj.name=label+'_'+obj.name
            obj.sk8_object.collision_mode=collision
            # Match the ReSkate Studio native donor and material selectors.
            obj.sk8_object.collision_material=mod.DEFAULT_COLLISION_MATERIAL
            for material in obj.data.materials:
                if material and hasattr(material,'sk8_material'):
                    material.sk8_material.surface=('concrete' if label=='Terrain' else 'asphalt' if label.startswith('Roads') else 'default')
            obj['sk8_collision_mode']=collision
            audit.append({'object':obj.name,'collision':collision,'polygons':len(obj.data.polygons)})
    survey=json.loads((root/'SPAWN_SURVEY_v24.json').read_text())
    x,y,z=survey['candidates'][0]['position_m']
    # Spawn is positioned from a surveyed real-terrain candidate; do not scale twice.
    spawn=bpy.data.objects.new('spawn',None)
    bpy.context.scene.collection.objects.link(spawn)
    spawn.location=(float(x),float(y),float(z)+1.25)
    spawn.empty_display_type='ARROWS'
    spawn.empty_display_size=1.0
    # Survey location is unverified in-game. A modest vertical offset prevents initial terrain intersection.
    dest.parent.mkdir(parents=True,exist_ok=True)
    assert len([o for o in bpy.context.scene.objects if o.name.casefold()=='spawn' and o.type=='EMPTY']) == 1
    assert bpy.context.scene.sk8_map.scale == 1.0
    bpy.ops.wm.save_as_mainfile(filepath=str(dest))
    report={'studio_addon':'Native/Blender/sk8_map_export.py','scale':1.0,'spawn':list(spawn.location),'spawn_status':'UNTESTED','objects':audit,'output':str(dest)}
    (dest.parent/'DETROIT_STUDIO_SCENE_AUDIT.json').write_text(json.dumps(report,indent=2))
    print('DETROIT313_SCENE_BUILT',dest)
