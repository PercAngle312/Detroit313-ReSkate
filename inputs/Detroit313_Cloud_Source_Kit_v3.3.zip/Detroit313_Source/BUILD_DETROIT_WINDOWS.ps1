param(
  [string]$StudioZip = '.\ReSkate Studio.zip',
  [string]$BlenderExe = '',
  [string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Skate',
  [switch]$Compile,
  [switch]$TexturePass
)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not [System.IO.Path]::IsPathRooted($StudioZip)) { $StudioZip=Join-Path $Root $StudioZip }
if (-not (Test-Path -LiteralPath $StudioZip)) { throw "Original ReSkate Studio.zip required at $StudioZip" }
if (-not $BlenderExe) {
  $Candidates=@(Get-ChildItem 'C:\Program Files\Blender Foundation' -Filter blender.exe -Recurse -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -ExpandProperty FullName)
  if ($Candidates.Count -eq 0) { throw 'Blender not found. Set -BlenderExe to its full path.' }
  $BlenderExe=$Candidates[0]
}
Write-Host 'Running source/Studio preflight'
$PythonExe=(Get-Command py -ErrorAction SilentlyContinue)
if (-not $PythonExe) { throw 'Python launcher py not found. Install Python 3 to run preflight.' }
& py -3 (Join-Path $Root 'preflight.py') $StudioZip
if ($LASTEXITCODE -ne 0) { throw 'Preflight failed' }
$OutputDir=Join-Path $Root 'build_output'
New-Item -Path $OutputDir -ItemType Directory -Force | Out-Null
$Blend=Join-Path $OutputDir 'Detroit313_CampusMartius.blend'
Write-Host "Generating Detroit Blender scene using $BlenderExe"
& $BlenderExe -b --python (Join-Path $Root 'build_detroit_studio_scene.py') -- $StudioZip $Root $Blend
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $Blend)) { throw 'Blender generation failed; see console above' }
Write-Host "Scene saved: $Blend"
if ($TexturePass) {
  Write-Host 'Applying visual-only preview textures to roads and buildings; measured terrain gameplay surfaces unchanged.'
  & $BlenderExe -b $Blend --python (Join-Path $Root 'apply_textures_in_blender.py')
  if ($LASTEXITCODE -ne 0) { throw 'Blender texture application failed' }
  $TexturedBlend=Join-Path $OutputDir 'Detroit313_CampusMartius_TEXTURED.blend'
  if (-not (Test-Path -LiteralPath $TexturedBlend)) { throw 'Textured scene missing' }
  Write-Host "Textured preview saved: $TexturedBlend"
}

if ($Compile) {
  if (-not (Test-Path -LiteralPath $GamePath)) { throw "Game directory missing: $GamePath" }
  $CliDir=Join-Path $OutputDir 'studio_cli'
  New-Item $CliDir -ItemType Directory -Force | Out-Null
  Expand-Archive -LiteralPath $StudioZip -DestinationPath $CliDir -Force
  $Cli=Join-Path $CliDir 'reskate_cli.exe'
  if (-not (Test-Path -LiteralPath $Cli)) { throw 'reskate_cli.exe missing from zip' }
  $Package=Join-Path $OutputDir 'Detroit313_Compiled'
  Write-Host 'Compiling with no --deploy; any output must be validated before installation.'
  & $Cli compile-map $GamePath $Blend $Package
  if ($LASTEXITCODE -ne 0) { throw "Compile failed, exit code $LASTEXITCODE" }
  Write-Host "Compiler returned success. Inspect package at $Package (not game-tested)."
}
