"""Portable source preflight for Detroit313 v2.7. No Blender required."""
import pathlib, json, hashlib, zipfile, sys
ROOT = pathlib.Path(__file__).resolve().parent
SOURCES = {
 'terrain': ROOT/'exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_TerrainCollision_CANDIDATE.glb',
 'roads': ROOT/'exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_Roads_VISUAL_ONLY.glb',
 'buildings': ROOT/'exports/CAMPUS_COLLISION_CANDIDATE_v23/CampusMartius_Buildings_VISUAL_ONLY.glb',
}
EXPECTED = json.loads((ROOT/'SHA256_SOURCES.json').read_text())
for key,p in SOURCES.items():
    assert p.is_file(), f'Missing {key}: {p}'
    digest=hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest == EXPECTED[key], f'Hash mismatch: {key}'
survey=json.loads((ROOT/'SPAWN_SURVEY_v24.json').read_text())
assert survey['candidates'] and len(survey['candidates'][0]['position_m'])==3
candidate=survey['candidates'][0]
assert candidate['status']=='SURVEY_CANDIDATE_ONLY'
assert candidate['terrain_slope_deg']<3
studio = pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'ReSkate Studio.zip'
if not studio.is_file():
    raise SystemExit(f'Missing Studio ZIP: {studio}. Pass its path: python preflight.py \"C:\\path\\ReSkate Studio.zip\"')
with zipfile.ZipFile(studio) as z:
    assert 'reskate_cli.exe' in z.namelist()
    code=z.read('Native/Blender/sk8_map_export.py').decode('utf-8')
    for marker in ('triangle_mesh','SPAWN_MARKER = "spawn"','collision_material','sk8_map'):
        assert marker in code, f'Studio API marker missing: {marker}'
print('PASS: source SHA256, spawn survey, Studio compiler and add-on requirements')
print('NOT TESTED: Blender generation, native compilation or in-game load')
